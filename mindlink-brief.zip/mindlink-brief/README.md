# Mindlink Systems – Growth Systems Brief

A Next.js project ready to deploy to Vercel. The brief lives at `/brief`.

## How to deploy

### Option A: Drag-and-drop (no terminal needed)
1. Go to vercel.com and sign up
2. Click "Add New Project"
3. Drag this entire folder into the upload area
4. Click Deploy
5. Wait ~60 seconds — you'll get a free URL like mindlink-brief.vercel.app/brief
6. To connect your own domain: Settings → Domains → add mindlink.ai → follow the DNS instructions

### Option B: Via GitHub (recommended for ongoing updates)
1. Create a new GitHub repo named "mindlink-brief"
2. Upload all files in this folder to it
3. In Vercel: Add New Project → Import from GitHub → select the repo
4. Click Deploy
5. Future edits: push to GitHub, Vercel auto-deploys

## How to connect mindlink.ai

In your domain registrar (wherever you bought mindlink.ai):
1. Add a CNAME record: brief → cname.vercel-dns.com
   (or whatever Vercel tells you to use)
2. In Vercel: Settings → Domains → add "brief.mindlink.ai"
3. Wait 5–60 mins for DNS to propagate

Your final URL will be: brief.mindlink.ai

## Editing the brief

Open app/brief/page.jsx. All copy and pricing live in this file. Edit, save, redeploy.
